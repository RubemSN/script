#!/bin/bash
LOGFILE="/usr/local/bin/scriptdiario/$(date +%d-%m-%Y_%H-%M)-scriptdiario.txt"
echo "Sistema iniciado às $(date)" >> "$LOGFILE"

echo "UPDATE...." >> "$LOGFILE" 2>&1
sudo apt update >> "$LOGFILE" 2>&1


echo "UPGRADE -Y..." >> "$LOGFILE" 2>&1

